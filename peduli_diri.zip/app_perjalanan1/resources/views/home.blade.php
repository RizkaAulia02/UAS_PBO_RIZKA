@extends('layout.app')
@section('content')

 <!--footer-->
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6>Peduli Diri</h6> 
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                <div class="container-fluid">
                <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-muted text-lg-start">
          <script>  
          </script><span style="color: black">Welcome To</span>  <i class="fa fa-heart" aria-hidden="true"></i> 
                <class="font-weight-bold" target="_blank" style="color:purple"> Peduli Diri</a>
        </div>
      </div>
  </div>
</footer>
<div class="container-fluid py-4">
  
    <div class="row">
        <div class="col-12">
           <h4 align="center"> Hello {{Auth::user()->username}}</h4>
            </div>
@endsection