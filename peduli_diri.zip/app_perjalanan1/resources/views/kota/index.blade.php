@extends('layout.app')
@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0">
              <h6>Peduli Diri</h6>
              <a class="btn btn-dark btn-sm ms-auto" href="/kota/create"> Tambah Data </a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Nama Kota</th>
                      <th class="text-secondary opacity-7"></th>
                    </tr>
                  </thead>
                  @foreach ($kota as $i => $a)
                  <tbody>
                    <tr>
                        <td class="align-middle text-center text-sm">{{$i+1}}</td>
                        <td class="align-middle text-center text-sm">{{$a->nama_kota}}</td>
                    </tr>
                  </tbody>
                  @endforeach
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kota</title>
</head>
<body>
    <center>
        <h2> Kota </h2>
    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Kota</th>
                <th>Tanggal Berangkat</th>
                <th>Waktu</th>
            </tr>
        </thead>
        @foreach ($kota as $i => $a)
        <tbody>
            <tr>
                <td>{{$i+1}}</td>
                <td>{{$a->nama_kota}}</td>
                <td>{{$a->tanggal}}</td>
                <td>{{$a->waktu}}</td}>
            
            </tr>
        </tbody>
        @endforeach
    </table>
    <a href="/kota/create"> Tambah Data </a>
</body>
</html> -->
@endsection