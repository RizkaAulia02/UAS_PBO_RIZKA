<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-md-10">
        <form action="/kota/store" method="post">
                <?php echo csrf_field(); ?>
          <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex align-items-center">
                <p class="mb-0">Kota</p>
                <button class="btn btn-dark btn-sm ms-auto">Save</button>
              </div>
            </div>
            <div class="card-body">
              <p class="text-uppercase text-sm">Data Kota</p>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="example-text-input" class="form-control-label">Nama Kota</label>
                    <input class="form-control" type="text" name="nama_kota">
                  </div>
                </div>
              </div>
            </div>
        </form>
        </div>
    </div>
</div>

<!-- <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nama Kota</title>
</head>
<body>
    <center>
        <h2> Kota </h2>
        <form action="/kota/store" method="post">
        <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td> Id Kota </td>
                <td> : <input type="text" name="id_kota"></td>
            </tr>
            <tr>
                <td> Nama Kota </td>
                <td> : <input type="text" name="nama_kota"></td>
            </tr>
            <tr>
                <td> Tanggal Berangkat </td>
                <td> : <input type="date" name="tanggal"></td>
            </tr>
            <tr>
                <td> Waktu </td>
                <td> : <input type="number" name="waktu"></td>
            </tr>
        </table>
         
        <br>
        <button type="submit"> Save </button>
        </body>
</html> -->

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_perjalanan1\resources\views/kota/create.blade.php ENDPATH**/ ?>