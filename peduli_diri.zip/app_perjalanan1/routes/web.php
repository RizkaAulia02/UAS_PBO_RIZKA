<?php



Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');


// perjalanan
Route::get('/perjalanan','PerjalananController@index');
Route::get('/perjalanan/create', 'PerjalananController@create');
Route::post('/perjalanan/store','PerjalananController@store');
Route::get('/perjalanan/edit/{id}', 'PerjalananController@edit');
Route::put('/perjalanan/update/{id}', 'PerjalananController@update');
Route::get('/perjalanan/destroy/{id}', 'PerjalananController@destroy');
Route::get('/perjalanan/show/{id}', 'PerjalananController@show');


// user
Route::get('/user','userController@index');
Route::get('/user/create','userController@create');
Route::post('/user/store','userController@store');
Route::get('/user/edit/{id}','userController@edit');
Route::post('/user/update/{id}','userController@update');
Route::get('/user/destroy/{id}', 'userController@destroy');
Route::post('/user/upload','userController@upload');

// kota
Route::get('/kota','KotaController@index');
Route::get('/kota/create','KotaController@create');
Route::post('/kota/store', 'KotaController@store');
Route::get('/kota/destroy/{id}', 'KotaController@destroy');


// home
// Route::get('/welcome','welcomeController@index');

// login
//  Route::get('/login','loginController@login')->name('login');
//  Route::post('/postlogin','loginController@postlogin')->name('postlogin');

// register


Route::get('/profile', 'HomeController@profile');
Route::get('/', function () {
    return view('welcome');
});

Route::get('/logout', function () {
    return view('home');
});


