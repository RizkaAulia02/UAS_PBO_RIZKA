<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Kota;
use Illuminate\Support\Facades\Hash;
class userController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = User::all();
        $kota = Kota::all();
        return view ('user.index', compact('user', 'kota'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user = User::all();
        $kota = Kota::all();
        return view('user.create', compact('user', 'kota'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
     
        // $foto = $request->file('user');
        // $file_name = $request->foto->getClientOriginalName();
        // $foto = $request->foto->storeAs('data.profil',$file_name);

        // $password = $request->password;
        $value= [
            'nik'=>$request->nik,
            'nama'=>$request-> nama,
            'telp'=>$request-> telp,
            'email'=>$request-> email,
            'foto'=>$request-> foto,
            'alamat'=>$request->alamat,
            'username'=>$request-> username,
            'password'=>$request-> password,
            // 'password'=>bcrypt('password'),
            // 'confirm'=>$request-> confirm
            ];
            $value['password'] = Hash::make($request->password);
            User::create($value);
            return redirect('/user');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $kota = Kota::all();
        $user = User::find($id);
        return view('user.edit', compact('user','kota'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $modal = User::find($id);
        $value = [
            'nik'=>$request->nik,
            'nama'=>$request-> nama,
            'telp'=>$request-> telp,
            'email'=>$request-> email,
            'foto'=>$request-> foto,
            'alamat'=>$request->alamat,
            'username'=>$request-> username,
        ];
        // $foto= $request->file('foto');
        // $file_nama = $foto->getClientOrginalName();
        // $foto = $request->foto->StoreAs('data_profil','$file_name');
        // $request->foto = $request->file('foto')->getClientOriginalName();


        $modal->update($value);
        return redirect('/user');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::destroy($id);
        return redirect('/user');
    }

    public function upload(Request $request){
        if($request->hasFile('user')){
            $resorce = $request->file('user');
            $name = $resorce->getClientOriginalName();
            $resorce->move(\base_path() ."/public/users", $name);
            $save = DB::table('users')->insert(['user'=> $name]);
            echo "Gambar Berhasil di Upload";
        }else{
            echo "Gagal Upload Gambar";
        
        }
    }
}
