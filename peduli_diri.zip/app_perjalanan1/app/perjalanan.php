<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class perjalanan extends Model
{
    protected $table ='perjalanans';
    protected $fillable = [
        'tanggal',
        'jam',
        'lokasi',
        'suhu_tubuh',
        'id_user'
    ];
    protected $primaryKey ='id';

    public function pengguna()
    {
        return $this->belongsTo('App\pengguna');
    }
}
